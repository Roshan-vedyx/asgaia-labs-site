document.addEventListener('DOMContentLoaded', () => {
  loadStatus();
  setupEventListeners();
});

async function loadStatus() {
  try {
    const result = await chrome.storage.local.get('neuroAccessibleSettings');
    const statusIndicator = document.getElementById('statusIndicator');
    
    if (result.neuroAccessibleSettings && Object.values(result.neuroAccessibleSettings).some(val => val !== false && val !== 'default' && val !== 0 && val !== 1.5 && val !== 16)) {
      statusIndicator.classList.add('active');
      statusIndicator.setAttribute('aria-label', 'Extension is active');
    } else {
      statusIndicator.classList.remove('active');
      statusIndicator.setAttribute('aria-label', 'Extension is inactive');
    }
  } catch (error) {
    console.error('Error loading status:', error);
    showNotification('Error loading status', 'error');
  }
}

function setupEventListeners() {
  document.getElementById('openWidget').addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await chrome.tabs.sendMessage(tab.id, { action: 'toggleWidget' });
      window.close();
    } catch (error) {
      console.error('Error opening widget:', error);
      showNotification('Please refresh the page and try again', 'error');
    }
  });

  document.getElementById('resetSettings').addEventListener('click', async () => {
    if (confirm('Are you sure you want to reset all accessibility settings?')) {
      try {
        await chrome.storage.local.remove('neuroAccessibleSettings');
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tab.id, { action: 'resetSettings' });
        await loadStatus();
        showNotification('Settings reset successfully', 'success');
      } catch (error) {
        console.error('Error resetting settings:', error);
        showNotification('Error resetting settings', 'error');
      }
    }
  });

  document.querySelectorAll('.quick-action').forEach(button => {
    button.addEventListener('click', async () => {
      const action = button.dataset.action;
      await applyQuickAction(action);
    });
  });
}

async function applyQuickAction(action) {
  try {
    const result = await chrome.storage.local.get('neuroAccessibleSettings');
    const settings = result.neuroAccessibleSettings || {
      font: 'default',
      fontSize: 16,
      letterSpacing: 0,
      wordSpacing: 0,
      lineHeight: 1.5,
      theme: 'default',
      reduceClutter: false,
      removeAds: false,
      focusMode: false
    };

    switch (action) {
      case 'dyslexia':
        settings.font = 'opendyslexic';
        settings.fontSize = 18;
        settings.letterSpacing = 1;
        settings.lineHeight = 1.8;
        break;
      case 'dark':
        settings.theme = settings.theme === 'dark' ? 'default' : 'dark';
        break;
      case 'focus':
        settings.focusMode = !settings.focusMode;
        settings.reduceClutter = settings.focusMode;
        break;
      case 'clutter':
        settings.reduceClutter = !settings.reduceClutter;
        settings.removeAds = settings.reduceClutter;
        break;
    }

    await chrome.storage.local.set({ neuroAccessibleSettings: settings });
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await chrome.tabs.sendMessage(tab.id, { action: 'applySettings', settings });
    
    await loadStatus();
    showNotification(`${getActionName(action)} applied`, 'success');
  } catch (error) {
    console.error(`Error applying quick action ${action}:`, error);
    showNotification('Please refresh the page and try again', 'error');
  }
}

function getActionName(action) {
  const names = {
    dyslexia: 'Dyslexia Mode',
    dark: 'Dark Mode',
    focus: 'Focus Mode',
    clutter: 'Clutter Reduction'
  };
  return names[action] || action;
}

function showNotification(message, type) {
  const existing = document.querySelector('.notification');
  if (existing) existing.remove();

  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove();
    }
  }, 3000);
}

document.addEventListener('keydown', (e) => {
  if (e.ctrlKey || e.metaKey) {
    e.preventDefault();
    switch (e.key) {
      case '1':
        applyQuickAction('dyslexia');
        break;
      case '2':
        applyQuickAction('dark');
        break;
      case '3':
        applyQuickAction('focus');
        break;
    }
  }
});