## 🧠 How to Install ClarityKey (for testers)

### 1. Download the Extension
- [Click here to download ClarityKey_Access_Tool.zip](https://drive.google.com/file/d/144nE71MqsIPT47_vtW243ztzmjTbFVp_/view?usp=drive_link)
- After download, **right-click → Extract All...** to unzip the folder

### 2. Install in Chrome
1. Open Google Chrome
2. Type `chrome://extensions` in the address bar and press Enter
3. Turn ON **Developer Mode** (top right)
4. Click **Load unpacked**
5. Select the unzipped folder called `ClarityKey_Access_Tool`

✅ You'll see the ClarityKey 🧠 icon appear in your toolbar. Click it to start using the tool!
