class NeuroAccessible {
  constructor() {
    this.settings = {
      font: 'default',
      fontSize: 16,
      letterSpacing: 0,
      wordSpacing: 0,
      lineHeight: 1.5,
      theme: 'default',
      reduceClutter: false,
      removeAds: false,
      focusMode: false
    };
    
    this.originalStyles = new Map();
    this.init();
  }

  async init() {
    await this.loadSettings();
    this.createFloatingButton();
    this.createWidget();
    this.applySettings();
    this.setupMessageListener();
  }

  async loadSettings() {
    try {
      const result = await chrome.storage.local.get('neuroAccessibleSettings');
      if (result.neuroAccessibleSettings) {
        this.settings = { ...this.settings, ...result.neuroAccessibleSettings };
      }
    } catch (error) {
      console.log('Using default settings');
    }
  }

  async saveSettings() {
    try {
      await chrome.storage.local.set({ neuroAccessibleSettings: this.settings });
    } catch (error) {
      console.error('Failed to save settings:', error);
    }
  }

  createFloatingButton() {
    const button = document.createElement('div');
    button.id = 'neuro-accessible-button';
    button.innerHTML = '🧠';
    button.title = 'Open Accessibility Settings';
    
    button.addEventListener('click', () => {
      this.toggleWidget();
    });
    
    document.body.appendChild(button);
  }

  createWidget() {
    const widget = document.createElement('div');
    widget.id = 'neuro-accessible-widget';
    widget.innerHTML = `
      <div class="na-header">
        <div class="na-logo">ClarityKey by Asgaia Studio</div>
        <button id="na-close" type="button" aria-label="Close Accessibility Settings">×</button>
      </div>
      
      <div class="na-content">
        <div class="na-section na-grid">
          <div class="na-grid-item">
            <label for="na-font">Font:</label>
            <select id="na-font" aria-label="Select Font">
              <option value="default">Default</option>
              <option value="opendyslexic">OpenDyslexic</option>
              <option value="lexend">Lexend</option>
              <option value="atkinson">Atkinson Hyperlegible</option>
            </select>
          </div>

          <div class="na-grid-item">
            <label for="na-font-size">Font Size: <span id="na-font-size-value">16px</span></label>
            <input type="range" id="na-font-size" min="12" max="32" value="16" aria-label="Adjust Font Size">
          </div>

          <div class="na-grid-item">
            <label for="na-letter-spacing">Letter Spacing: <span id="na-letter-spacing-value">0px</span></label>
            <input type="range" id="na-letter-spacing" min="0" max="5" step="0.1" value="0" aria-label="Adjust Letter Spacing">
          </div>

          <div class="na-grid-item">
            <label for="na-word-spacing">Word Spacing: <span id="na-word-spacing-value">0px</span></label>
            <input type="range" id="na-word-spacing" min="0" max="10" step="0.5" value="0" aria-label="Adjust Word Spacing">
          </div>

          <div class="na-grid-item">
            <label for="na-line-height">Line Height: <span id="na-line-height-value">1.5</span></label>
            <input type="range" id="na-line-height" min="1" max="3" step="0.1" value="1.5" aria-label="Adjust Line Height">
          </div>

          <div class="na-grid-item">
            <label for="na-theme">Theme:</label>
            <select id="na-theme" aria-label="Select Theme">
              <option value="default">Default</option>
              <option value="dark">Dark Mode</option>
              <option value="high-contrast">High Contrast</option>
              <option value="sepia">Sepia</option>
            </select>
          </div>

          <div class="na-grid-item na-checkboxes">
            <label class="na-checkbox">
              <input type="checkbox" id="na-reduce-clutter" aria-label="Reduce Clutter">
              <span class="na-checkmark"></span>
              Reduce Clutter
            </label>
            <label class="na-checkbox">
              <input type="checkbox" id="na-remove-ads" aria-label="Remove Ads">
              <span class="na-checkmark"></span>
              Remove Ads
            </label>
            <label class="na-checkbox">
              <input type="checkbox" id="na-focus-mode" aria-label="Focus Mode">
              <span class="na-checkmark"></span>
              Focus Mode
            </label>
          </div>
        </div>

        <div class="na-preview">
          <h4>Preview Text</h4>
          <p id="na-preview-text">
            The quick brown fox jumps over the lazy dog. This is a sample text to preview your accessibility settings. 123456789
          </p>
        </div>

        <div class="na-buttons">
          <button id="na-apply" type="button" aria-label="Apply Settings">Apply Settings</button>
          <button id="na-reset" type="button" aria-label="Reset Settings">Reset</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(widget);
    this.setupWidgetEvents();
    this.updateWidgetValues();
  }

  setupWidgetEvents() {
    // Debounce utility to limit rapid updates
    const debounce = (func, wait) => {
      let timeout;
      return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
      };
    };

    document.getElementById('na-close').addEventListener('click', () => {
      this.hideWidget();
    });

    document.getElementById('na-font').addEventListener('change', (e) => {
      this.settings.font = e.target.value;
      this.updatePreview();
    });

    const fontSizeSlider = document.getElementById('na-font-size');
    fontSizeSlider.addEventListener('input', debounce((e) => {
      this.settings.fontSize = parseInt(e.target.value);
      document.getElementById('na-font-size-value').textContent = e.target.value + 'px';
      this.updatePreview();
    }, 50));

    const letterSpacingSlider = document.getElementById('na-letter-spacing');
    letterSpacingSlider.addEventListener('input', debounce((e) => {
      this.settings.letterSpacing = parseFloat(e.target.value);
      document.getElementById('na-letter-spacing-value').textContent = e.target.value + 'px';
      this.updatePreview();
    }, 50));

    const wordSpacingSlider = document.getElementById('na-word-spacing');
    wordSpacingSlider.addEventListener('input', debounce((e) => {
      this.settings.wordSpacing = parseFloat(e.target.value);
      document.getElementById('na-word-spacing-value').textContent = e.target.value + 'px';
      this.updatePreview();
    }, 50));

    const lineHeightSlider = document.getElementById('na-line-height');
    lineHeightSlider.addEventListener('input', debounce((e) => {
      this.settings.lineHeight = parseFloat(e.target.value);
      document.getElementById('na-line-height-value').textContent = e.target.value;
      this.updatePreview();
    }, 50));

    document.getElementById('na-theme').addEventListener('change', (e) => {
      this.settings.theme = e.target.value;
      this.updatePreview();
    });

    document.getElementById('na-reduce-clutter').addEventListener('change', (e) => {
      this.settings.reduceClutter = e.target.checked;
      this.updatePreview();
    });

    document.getElementById('na-remove-ads').addEventListener('change', (e) => {
      this.settings.removeAds = e.target.checked;
      this.updatePreview();
    });

    document.getElementById('na-focus-mode').addEventListener('change', (e) => {
      this.settings.focusMode = e.target.checked;
      if (this.settings.focusMode) {
        this.enableFocusMode();
      } else {
        this.disableFocusMode();
      }
      this.updatePreview();
    });

    document.getElementById('na-apply').addEventListener('click', () => {
      this.applySettings();
      this.saveSettings();
      this.hideWidget();
    });

    document.getElementById('na-reset').addEventListener('click', () => {
      this.resetSettings();
    });
  }

  updateWidgetValues() {
    document.getElementById('na-font').value = this.settings.font;
    document.getElementById('na-font-size').value = this.settings.fontSize;
    document.getElementById('na-font-size-value').textContent = this.settings.fontSize + 'px';
    document.getElementById('na-letter-spacing').value = this.settings.letterSpacing;
    document.getElementById('na-letter-spacing-value').textContent = this.settings.letterSpacing + 'px';
    document.getElementById('na-word-spacing').value = this.settings.wordSpacing;
    document.getElementById('na-word-spacing-value').textContent = this.settings.wordSpacing + 'px';
    document.getElementById('na-line-height').value = this.settings.lineHeight;
    document.getElementById('na-line-height-value').textContent = this.settings.lineHeight;
    document.getElementById('na-theme').value = this.settings.theme;
    document.getElementById('na-reduce-clutter').checked = this.settings.reduceClutter;
    document.getElementById('na-remove-ads').checked = this.settings.removeAds;
    document.getElementById('na-focus-mode').checked = this.settings.focusMode;
    
    this.updatePreview();
  }

  updatePreview() {
    const previewText = document.getElementById('na-preview-text');
    if (!previewText) {
      console.warn('ClarityKey: Preview text element not found');
      return;
    }

    // Reset all styles and classes to avoid conflicts
    previewText.style.cssText = '';
    previewText.classList.remove('na-theme-dark', 'na-theme-high-contrast', 'na-theme-sepia');

    // Apply theme classes first
    this.applyThemeToElement(previewText, this.settings.theme);

    // Apply inline styles with !important to override any conflicting styles
    const fontFamily = this.getFontFamily(this.settings.font);
    let styles = `
      font-size: ${this.settings.fontSize}px !important;
      letter-spacing: ${this.settings.letterSpacing}px !important;
      word-spacing: ${this.settings.wordSpacing}px !important;
      line-height: ${this.settings.lineHeight} !important;
    `;
    if (fontFamily) {
      styles += `font-family: ${fontFamily} !important;`;
    }
    previewText.style.cssText = styles;

    // Log applied values for debugging
    console.log('ClarityKey: Preview updated with settings:', {
      font: this.settings.font,
      fontSize: this.settings.fontSize + 'px',
      letterSpacing: this.settings.letterSpacing + 'px',
      wordSpacing: this.settings.wordSpacing + 'px',
      lineHeight: this.settings.lineHeight,
      theme: this.settings.theme
    });
    console.log('ClarityKey: Preview styles applied:', previewText.style.cssText);
  }

  getFontFamily(font) {
    const fonts = {
      'default': null,
      'opendyslexic': '"OpenDyslexic", "Comic Sans MS", cursive',
      'lexend': '"Lexend", "Segoe UI", sans-serif',
      'atkinson': '"Atkinson Hyperlegible", "Arial", sans-serif'
    };
    return fonts[font] || null;
  }

  applySettings() {
    this.removeAllStyles();
    
    const css = this.generateCSS();
    const styleElement = document.createElement('style');
    styleElement.id = 'neuro-accessible-styles';
    styleElement.textContent = css;
    document.head.appendChild(styleElement);

    if (this.settings.reduceClutter) {
      this.reduceClutter();
    }

    if (this.settings.removeAds) {
      this.removeAds();
    }

    if (this.settings.focusMode) {
      this.enableFocusMode();
    } else {
      this.disableFocusMode();
    }
  }

  generateCSS() {
    const fontFamily = this.getFontFamily(this.settings.font);
    
    let css = `
      /* Typography Settings */
      *, *::before, *::after {
        ${fontFamily ? `font-family: ${fontFamily} !important;` : ''}
        font-size: ${this.settings.fontSize}px !important;
        letter-spacing: ${this.settings.letterSpacing}px !important;
        word-spacing: ${this.settings.wordSpacing}px !important;
        line-height: ${this.settings.lineHeight} !important;
      }
      
      /* Preserve heading hierarchy */
      h1 { font-size: ${this.settings.fontSize * 2}px !important; }
      h2 { font-size: ${this.settings.fontSize * 1.75}px !important; }
      h3 { font-size: ${this.settings.fontSize * 1.5}px !important; }
      h4 { font-size: ${this.settings.fontSize * 1.25}px !important; }
      h5 { font-size: ${this.settings.fontSize * 1.1}px !important; }
      h6 { font-size: ${this.settings.fontSize}px !important; }
      
      /* Small text elements */
      small, .small { font-size: ${this.settings.fontSize * 0.875}px !important; }
    `;

    css += this.getThemeCSS(this.settings.theme);

    return css;
  }

  getThemeCSS(theme) {
    const themes = {
      'dark': `
        * { 
          background-color: #1a1a1a !important; 
          color: #e0e0e0 !important; 
        }
        a { color: #4da6ff !important; }
        input, textarea, select { 
          background-color: #2d2d2d !important; 
          color: #e0e0e0 !important; 
          border: 1px solid #555 !important; 
        }
      `,
      'high-contrast': `
        * { 
          background-color: #000000 !important; 
          color: #ffff00 !important; 
        }
        a { color: #00ff00 !important; }
        input, textarea, select { 
          background-color: #000000 !important; 
          color: #ffff00 !important; 
          border: 2px solid #ffff00 !important; 
        }
      `,
      'sepia': `
        * { 
          background-color: #f4f3e8 !important; 
          color: #5c4b37 !important; 
        }
        a { color: #8b4513 !important; }
        input, textarea, select { 
          background-color: #f4f3e8 !important; 
          color: #5c4b37 !important; 
          border: 1px solid #d2b48c !important; 
        }
      `
    };
    
    return themes[theme] || '';
  }

  applyThemeToElement(element, theme) {
    element.classList.remove('na-theme-dark', 'na-theme-high-contrast', 'na-theme-sepia');
    if (theme !== 'default') {
      element.classList.add(`na-theme-${theme}`);
    }
  }

  reduceClutter() {
    const clutterSelectors = [
      'aside', '.sidebar', '.advertisement', '.ad', '.ads', 
      '.social-share', '.related-posts', '.comments', 
      '.newsletter-signup', '.popup', '.modal', 
      '[class*="banner"]', '[class*="promo"]'
    ];
    
    let hiddenCount = 0;
    clutterSelectors.forEach(selector => {
      document.querySelectorAll(selector).forEach(el => {
        el.style.display = 'none';
        hiddenCount++;
      });
    });
    console.log(`ClarityKey: Hid ${hiddenCount} clutter elements`);
  }

  removeAds() {
    const adSelectors = [
      '.ad', '.ads', '.advertisement', '.adsystem', 
      '[class*="google-ads"]', '[class*="adsense"]',
      '[id*="ad"]', '[class*="ad-"]', '.sponsored',
      'iframe[src*="googlesyndication"]',
      'iframe[src*="googletagmanager"]'
    ];
    
    let removedCount = 0;
    adSelectors.forEach(selector => {
      document.querySelectorAll(selector).forEach(el => {
        el.remove();
        removedCount++;
      });
    });
    console.log(`ClarityKey: Removed ${removedCount} ad elements`);
  }

  enableFocusMode() {
    const overlay = document.createElement('div');
    overlay.id = 'na-focus-overlay';
    document.body.appendChild(overlay);
    
    document.addEventListener('pointerenter', this.handlePointerEnter.bind(this), { capture: true });
  }

  disableFocusMode() {
    const overlay = document.getElementById('na-focus-overlay');
    if (overlay) overlay.remove();
    
    document.removeEventListener('pointerenter', this.handlePointerEnter.bind(this), { capture: true });
    
    document.querySelectorAll('.na-focused').forEach(el => {
      el.classList.remove('na-focused');
    });
  }

  handlePointerEnter(e) {
    if (!this.settings.focusMode) return;
    
    const target = e.target;
    if (
      !target ||
      target === document.body ||
      target === document.documentElement ||
      target.closest('#neuro-accessible-widget') ||
      target.closest('#neuro-accessible-button') ||
      !target.offsetWidth || !target.offsetHeight ||
      !target.textContent.trim()
    ) {
      return;
    }
    
    this.highlightElement(target);
  }

  highlightElement(element) {
    document.querySelectorAll('.na-focused').forEach(el => {
      el.classList.remove('na-focused');
    });
    
    element.classList.add('na-focused');
  }

  removeAllStyles() {
    const existingStyles = document.getElementById('neuro-accessible-styles');
    if (existingStyles) {
      existingStyles.remove();
    }

    const overlay = document.getElementById('na-focus-overlay');
    if (overlay) {
      overlay.remove();
    }

    document.querySelectorAll('.na-focused').forEach(el => {
      el.classList.remove('na-focused');
    });

    document.querySelectorAll('[style*="display: none"]').forEach(el => {
      el.style.display = '';
    });
  }

  resetSettings() {
    this.settings = {
      font: 'default',
      fontSize: 16,
      letterSpacing: 0,
      wordSpacing: 0,
      lineHeight: 1.5,
      theme: 'default',
      reduceClutter: false,
      removeAds: false,
      focusMode: false
    };
    
    this.updateWidgetValues();
    this.applySettings();
    this.saveSettings();
  }

  toggleWidget() {
    const widget = document.getElementById('neuro-accessible-widget');
    if (widget.style.display === 'none' || !widget.style.display) {
      this.showWidget();
    } else {
      this.hideWidget();
    }
  }

  showWidget() {
    const widget = document.getElementById('neuro-accessible-widget');
    widget.style.display = 'block';
  }

  hideWidget() {
    const widget = document.getElementById('neuro-accessible-widget');
    widget.style.display = 'none';
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'toggleWidget') {
        this.toggleWidget();
      } else if (request.action === 'applySettings' && request.settings) {
        this.settings = { ...this.settings, ...request.settings };
        this.updateWidgetValues();
        this.applySettings();
      } else if (request.action === 'resetSettings') {
        this.resetSettings();
      }
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new NeuroAccessible();
  });
} else {
  new NeuroAccessible();
}