/**
 * Initializes the extension on install, setting default settings and context menus.
 */
chrome.runtime.onInstalled.addListener(() => {
  console.log('ClarityKey by Asgaia Studio installed');

  // Set default settings
  chrome.storage.local.get('neuroAccessibleSettings').then((result) => {
    if (!result.neuroAccessibleSettings) {
      const defaultSettings = {
        font: 'default',
        fontSize: 16,
        letterSpacing: 0,
        wordSpacing: 0,
        lineHeight: 1.5,
        theme: 'default',
        reduceClutter: false,
        removeAds: false,
        focusMode: false
      };
      chrome.storage.local.set({ neuroAccessibleSettings: defaultSettings });
    }
  });

  // Create context menus
  chrome.contextMenus.create({
    id: 'claritykey-menu',
    title: 'ClarityKey by Asgaia Studio',
    contexts: ['all']
  });
  chrome.contextMenus.create({
    id: 'open-widget',
    parentId: 'claritykey-menu',
    title: 'Open Accessibility Widget',
    contexts: ['all']
  });
  chrome.contextMenus.create({
    id: 'dyslexia-mode',
    parentId: 'claritykey-menu',
    title: 'Toggle Dyslexia Mode',
    contexts: ['all']
  });
  chrome.contextMenus.create({
    id: 'dark-mode',
    parentId: 'claritykey-menu',
    title: 'Toggle Dark Mode',
    contexts: ['all']
  });
  chrome.contextMenus.create({
    id: 'focus-mode',
    parentId: 'claritykey-menu',
    title: 'Toggle Focus Mode',
    contexts: ['all']
  });
  chrome.contextMenus.create({
    id: 'reduce-clutter',
    parentId: 'claritykey-menu',
    title: 'Toggle Clutter Reduction',
    contexts: ['all']
  });
});

/**
 * Handles keyboard shortcut commands.
 * @param {string} command - The command triggered.
 */
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    switch (command) {
      case 'toggle-widget':
        await chrome.tabs.sendMessage(tab.id, { action: 'toggleWidget' });
        break;
      case 'toggle-dyslexia':
        await applyQuickAction(tab.id, 'dyslexia');
        break;
      case 'toggle-dark-mode':
        await toggleQuickSetting(tab.id, 'theme', 'dark');
        break;
      case 'toggle-focus-mode':
        await toggleQuickSetting(tab.id, 'focusMode');
        break;
      default:
        console.warn(`Unknown command: ${command}`);
    }
  } catch (error) {
    console.error(`Error handling command ${command}:`, error);
  }
});

/**
 * Toggles a setting and applies it to the specified tab.
 * @param {number} tabId - The ID of the tab.
 * @param {string} setting - The setting to toggle.
 * @param {string} [value] - Optional value to set (e.g., 'dark' for theme).
 */
async function toggleQuickSetting(tabId, setting, value) {
  try {
    const result = await chrome.storage.local.get('neuroAccessibleSettings');
    const settings = result.neuroAccessibleSettings || {
      font: 'default',
      fontSize: 16,
      letterSpacing: 0,
      wordSpacing: 0,
      lineHeight: 1.5,
      theme: 'default',
      reduceClutter: false,
      removeAds: false,
      focusMode: false
    };
    if (value !== undefined) {
      settings[setting] = settings[setting] === value ? 'default' : value;
    } else {
      settings[setting] = !settings[setting];
      if (setting === 'reduceClutter' && settings[setting]) {
        settings.removeAds = true;
      } else if (setting === 'focusMode' && settings[setting]) {
        settings.reduceClutter = true;
      }
    }
    await chrome.storage.local.set({ neuroAccessibleSettings: settings });
    await chrome.tabs.sendMessage(tabId, { action: 'applySettings', settings });
  } catch (error) {
    console.error(`Error toggling setting ${setting}:`, error);
  }
}

/**
 * Applies a quick action to the specified tab.
 * @param {number} tabId - The ID of the tab.
 * @param {string} action - The action to apply (e.g., 'dyslexia').
 */
async function applyQuickAction(tabId, action) {
  try {
    const result = await chrome.storage.local.get('neuroAccessibleSettings');
    const settings = result.neuroAccessibleSettings || {
      font: 'default',
      fontSize: 16,
      letterSpacing: 0,
      wordSpacing: 0,
      lineHeight: 1.5,
      theme: 'default',
      reduceClutter: false,
      removeAds: false,
      focusMode: false
    };
    switch (action) {
      case 'dyslexia':
        settings.font = 'opendyslexic';
        settings.fontSize = 18;
        settings.letterSpacing = 1;
        settings.lineHeight = 1.8;
        break;
      default:
        console.warn(`Unknown action: ${action}`);
    }
    await chrome.storage.local.set({ neuroAccessibleSettings: settings });
    await chrome.tabs.sendMessage(tabId, { action: 'applySettings', settings });
  } catch (error) {
    console.error(`Error applying action ${action}:`, error);
  }
}

/**
 * Handles context menu clicks.
 * @param {Object} info - Information about the context menu click.
 * @param {Object} tab - The tab where the click occurred.
 */
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    switch (info.menuItemId) {
      case 'open-widget':
        await chrome.tabs.sendMessage(tab.id, { action: 'toggleWidget' });
        break;
      case 'dyslexia-mode':
        await applyQuickAction(tab.id, 'dyslexia');
        break;
      case 'dark-mode':
        await toggleQuickSetting(tab.id, 'theme', 'dark');
        break;
      case 'focus-mode':
        await toggleQuickSetting(tab.id, 'focusMode');
        break;
      case 'reduce-clutter':
        await toggleQuickSetting(tab.id, 'reduceClutter');
        break;
      default:
        console.warn(`Unknown menu item: ${info.menuItemId}`);
    }
  } catch (error) {
    console.error('Error handling context menu click:', error);
  }
});

/**
 * Logs changes to settings.
 */
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.neuroAccessibleSettings) {
    console.log('Settings updated:', changes.neuroAccessibleSettings.newValue);
  }
});

/**
 * Applies settings on tab updates with retry logic.
 * @param {number} tabId - The ID of the tab.
 * @param {Object} changeInfo - Information about the tab update.
 * @param {Object} tab - The tab object.
 */
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && !tab.url.startsWith('chrome://')) {
    try {
      const result = await chrome.storage.local.get('neuroAccessibleSettings');
      if (result.neuroAccessibleSettings) {
        let attempts = 0;
        const maxAttempts = 3;
        const retryDelay = 1000;
        async function tryApplySettings() {
          try {
            await chrome.tabs.sendMessage(tabId, {
              action: 'applySettings',
              settings: result.neuroAccessibleSettings
            });
          } catch (error) {
            if (attempts < maxAttempts) {
              attempts++;
              console.warn(`Retrying settings application (${attempts}/${maxAttempts})`);
              setTimeout(tryApplySettings, retryDelay);
            } else {
              console.error(`Failed to apply settings after ${maxAttempts} attempts:`, error);
            }
          }
        }
        await tryApplySettings();
      }
    } catch (error) {
      console.error('Error maintaining settings on tab update:', error);
    }
  }
});

/**
 * Handles messages for exporting and importing settings.
 * @param {Object} request - The message request.
 * @param {Object} sender - The sender of the message.
 * @param {Function} sendResponse - The response callback.
 * @returns {boolean} True to indicate asynchronous response.
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'exportSettings') {
    chrome.storage.local.get('neuroAccessibleSettings').then((result) => {
      const settings = result.neuroAccessibleSettings || {};
      const dataStr = JSON.stringify(settings, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      chrome.downloads.download({
        url: URL.createObjectURL(dataBlob),
        filename: 'claritykey-settings.json',
        saveAs: true
      }, (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ success: true });
        }
      });
    });
    return true;
  }
  if (request.action === 'importSettings') {
    try {
      const settings = JSON.parse(request.settings);
      const validKeys = [
        'font', 'fontSize', 'letterSpacing', 'wordSpacing',
        'lineHeight', 'theme', 'reduceClutter', 'removeAds', 'focusMode'
      ];
      const isValid = Object.keys(settings).every(key => validKeys.includes(key));
      if (!isValid) throw new Error('Invalid settings format');
      if (settings.font && !['default', 'opendyslexic', 'lexend', 'atkinson'].includes(settings.font)) {
        throw new Error('Invalid font value');
      }
      if (settings.fontSize && (typeof settings.fontSize !== 'number' || settings.fontSize < 12 || settings.fontSize > 32)) {
        throw new Error('Invalid fontSize value');
      }
      if (settings.letterSpacing && (typeof settings.letterSpacing !== 'number' || settings.letterSpacing < 0 || settings.letterSpacing > 5)) {
        throw new Error('Invalid letterSpacing value');
      }
      if (settings.wordSpacing && (typeof settings.wordSpacing !== 'number' || settings.wordSpacing < 0 || settings.wordSpacing > 10)) {
        throw new Error('Invalid wordSpacing value');
      }
      if (settings.lineHeight && (typeof settings.lineHeight !== 'number' || settings.lineHeight < 1 || settings.lineHeight > 3)) {
        throw new Error('Invalid lineHeight value');
      }
      if (settings.theme && !['default', 'dark', 'high-contrast', 'sepia'].includes(settings.theme)) {
        throw new Error('Invalid theme value');
      }
      if (typeof settings.reduceClutter !== 'boolean' || typeof settings.removeAds !== 'boolean' || typeof settings.focusMode !== 'boolean') {
        throw new Error('Invalid boolean settings');
      }
      chrome.storage.local.set({ neuroAccessibleSettings: settings }).then(() => {
        chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
          chrome.tabs.sendMessage(tab.id, { action: 'applySettings', settings });
          sendResponse({ success: true });
        });
      });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }
  return false;
});